#!/bin/bash
echo "=========================================================="
echo "  DHCP Relay Router Infrastructure Status               "
echo "=========================================================="
echo "IP Forwarding: $(sysctl -n net.ipv4.ip_forward)"
echo "Interfaces:"
ip -brief addr show
echo ""
echo "dhcrelay process:"
if pgrep dhcrelay >/dev/null; then
    ps aux | grep dhcrelay | grep -v grep
    echo "  [OK] dhcrelay is ACTIVE."
else
    echo "  [WARN] dhcrelay not active. Starting..."
    sudo /usr/sbin/dhcrelay -4 -i eth0 -i eth1 192.168.0.100 2>/dev/null || true
fi
echo "=========================================================="
