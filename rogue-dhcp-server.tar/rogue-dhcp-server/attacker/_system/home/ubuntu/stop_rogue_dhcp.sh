#!/bin/bash
# Stop Rogue DHCP Server
echo "[*] Stopping Rogue DHCP Server process..."
sudo pkill -f rogue_dhcp.py 2>/dev/null || true
sleep 1
if ! pgrep -f rogue_dhcp.py >/dev/null; then
    echo "[OK] Rogue DHCP Server stopped."
else
    sudo pkill -9 -f rogue_dhcp.py 2>/dev/null || true
    echo "[OK] Rogue DHCP Server forcibly terminated."
fi
