#!/bin/bash
OUTFILE="${1:-/tmp/dhcp_capture.pcap}"
echo "[*] Capturing DHCP traffic on eth0. Press Ctrl+C to stop."
echo "[*] Output file: $OUTFILE"
sudo tcpdump -nv -i eth0 port 67 or port 68 -w "$OUTFILE"
