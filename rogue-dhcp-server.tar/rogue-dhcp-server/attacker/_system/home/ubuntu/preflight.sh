#!/bin/bash
echo "================================================================"
echo "  Attacker Preflight Connectivity Check"
echo "================================================================"
echo "[1] Interface eth0:"
ip -brief addr show eth0 || ip addr show eth0
echo ""
echo "[2] Default route to DHCP Relay (10.10.0.1):"
ip route add default via 10.10.0.1 2>/dev/null || true
ping -c 2 -W 2 10.10.0.1 && echo "  [OK] Relay 10.10.0.1 reachable." || echo "  [FAIL] Relay unreachable."
echo ""
echo "[3] Ping Snort Sensor (10.10.0.30):"
ping -c 2 -W 2 10.10.0.30 && echo "  [OK] Snort 10.10.0.30 reachable." || echo "  [FAIL] Snort unreachable."
echo "================================================================"
