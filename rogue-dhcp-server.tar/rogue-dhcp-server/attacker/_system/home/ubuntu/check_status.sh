#!/bin/bash
echo "=========================================================="
echo "  Rogue DHCP Server Status & Logs"
echo "=========================================================="
echo "Process status:"
if pgrep -f rogue_dhcp.py >/dev/null; then
    echo "  [ACTIVE] Rogue DHCP Server is RUNNING (PID $(pgrep -f rogue_dhcp.py))"
else
    echo "  [INACTIVE] Rogue DHCP Server is NOT running."
fi
echo ""
echo "Recent Logs (/var/log/rogue_dhcp.log):"
if [ -f /var/log/rogue_dhcp.log ]; then
    tail -n 15 /var/log/rogue_dhcp.log
else
    echo "  (No log file created yet)"
fi
echo "=========================================================="
