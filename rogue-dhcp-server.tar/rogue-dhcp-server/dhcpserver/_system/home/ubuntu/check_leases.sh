#!/bin/bash
echo "=========================================================="
echo "  Legitimate DHCP Server (192.168.0.100) Lease Status     "
echo "=========================================================="
echo "Service status:"
if pgrep dhcpd >/dev/null; then
    echo "  [OK] isc-dhcp-server (dhcpd) is RUNNING (PID $(pgrep dhcpd))"
else
    echo "  [WARN] dhcpd is NOT running! Restarting..."
    sudo /usr/sbin/dhcpd -4 -cf /etc/dhcp/dhcpd.conf -pf /var/run/dhcpd.pid eth0 2>/dev/null || true
fi

echo ""
echo "Active leases in /var/lib/dhcp/dhcpd.leases:"
if [ -f /var/lib/dhcp/dhcpd.leases ]; then
    grep -E "lease |binding state|hardware ethernet|client-hostname" /var/lib/dhcp/dhcpd.leases | tail -n 20
else
    echo "  (No lease file found)"
fi
echo "=========================================================="
