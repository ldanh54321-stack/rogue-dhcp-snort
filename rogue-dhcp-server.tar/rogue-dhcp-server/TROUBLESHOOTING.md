# Hướng Dẫn Khắc Phục Sự Cố (Troubleshooting Guide)

| Tình huống sự cố | Nguyên nhân khả dĩ | Hướng xử lý |
| :--- | :--- | :--- |
| **Client chạy `./request_ip.sh` nhưng không nhận được IP (Timeout)** | Dịch vụ `dhcrelay` hoặc `dhcpd` trên máy chủ chưa sẵn sàng. | 1. Trên terminal `dhcpserver`, chạy `./check_leases.sh` để đảm bảo `dhcpd` đang chạy.<br>2. Thử chạy lại `./release_ip.sh` rồi `./request_ip.sh` trên client. |
| **Snort không hiển thị cảnh báo khi Rogue DHCP phát gói** | Tiến trình Snort daemon chưa chạy hoặc chưa đặt card mạng ở chế độ promiscuous. | 1. Chạy `./verify_snort.sh` trên terminal `snort` để kiểm tra lỗi cú pháp rule.<br>2. Chạy `./view_alerts.sh` (script sẽ tự động khởi động daemon nếu bị tắt). |
| **Client vẫn nhận IP hợp lệ thay vì IP của Rogue DHCP** | Cạnh tranh thời gian phản hồi (Race Condition): gói tin từ DHCP Relay đến trước Rogue DHCP. | 1. Đảm bảo Rogue DHCP Server đang thực sự active bằng `./check_status.sh` trên `attacker`.<br>2. Chạy lại `./request_ip.sh` trên client vài lần (trong mạng cục bộ cùng switch/bridge ảo, Rogue DHCP thường phản hồi nhanh hơn do không phải qua relay 2 subnet). |
| **Lệnh `labtainer -r rogue-dhcp-server` báo lỗi image missing** | Tên image trong Docker local bị thiếu tag hoặc registry khác biệt. | Chạy lệnh `docker images \| grep dhcp-lab` để kiểm tra. Hệ thống sử dụng registry `huynguyen1324` với tag `latest`. |
| **Một container bị mất terminal hiển thị** | Labtainer gặp trục trặc khi mở cửa sổ xterm. | Bạn có thể mở thêm terminal tương tác bất kỳ lúc nào bằng lệnh:<br>`moreterm.py rogue-dhcp-server <tên_container>` (ví dụ: `moreterm.py rogue-dhcp-server attacker`). |
