# Rogue DHCP Server, Snort NIDS Detection & Defense Lab (`rogue-dhcp-server`)

Repository: **`rogue-dhcp-snort`**  
Tên bài Labtainer: **`rogue-dhcp-server`**  
Phiên bản: **`v1.0.0`**

---

## 1. Giới thiệu & Mục tiêu
Bài lab **`rogue-dhcp-server`** mô phỏng tình huống tấn công máy chủ DHCP giả mạo (Rogue DHCP Server) trong một hệ thống mạng phân đoạn (Dual-Subnet) có sử dụng DHCP Relay. Bài lab trang bị kiến thức thực tế về:
- Nguyên lý hoạt động của giao thức DHCP (Discover, Offer, Request, ACK).
- Nguy cơ an ninh khi xuất hiện Rogue DHCP Server (Man-in-the-Middle, DNS Spoofing, chiếm đoạt Default Gateway).
- Xây dựng tập luật Snort 2.9 NIDS chuyên sâu để phát hiện các thông điệp DHCP Offer/ACK trái phép trong thời gian thực.
- Triển khai và kiểm chứng giải pháp phòng chống chuẩn của DHCP client (`reject` directive trong `dhclient.conf`).

---

## 2. Kiến trúc Mạng & Tích hợp Mạng nền (`labtainer-network-base`)

Bài lab kế thừa kiến trúc Dual-Subnet chuẩn từ repository mạng nền **`labtainer-network-base`** (phiên bản `>= 1.0.0`), sử dụng container Linux riêng làm DHCP Relay (không sử dụng pfSense):

| Thành phần | Container | Subnet | IP Address | MAC Address | Image chuẩn | Vai trò |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **DHCP Server** | `dhcpserver` | `INTERNAL_NET` | `192.168.0.100` | `02:42:c0:a8:00:64` | `dhcp-lab.dhcpserver` | ISC DHCP Server hợp lệ, cấp dải `10.10.0.100 - 10.10.0.130` |
| **DHCP Relay** | `dhcprelay` | Dual-Homed | eth0: `192.168.0.1`<br>eth1: `10.10.0.1` | `02:42:c0:a8:00:01`<br>`02:42:0a:0a:00:01` | `dhcp-lab.dhcprelay` | Router chuyển tiếp DHCP giữa Internal và External (`TERMINALS 0`) |
| **Attacker** | `attacker` | `EXTERNAL_NET` | `10.10.0.20` | `02:42:0a:0a:00:14` | `dhcp-lab.attacker` | Kali / Scapy Rogue DHCP Server (`rogue_dhcp.py`) |
| **Sensor NIDS** | `snort` | `EXTERNAL_NET` | `10.10.0.30` | `02:42:0a:0a:00:1e` | `dhcp-lab.snort` | Snort 2.9 giám sát card mạng `eth0` ở chế độ promiscuous |
| **Client** | `client` | `EXTERNAL_NET` | `10.10.0.50` (Init) | `02:42:0a:0a:00:32` | `dhcp-lab.client` | Máy nạn nhân Ubuntu Client xin IP động |

*Lưu ý tích hợp `labtainer-network-base`*: Nếu trên máy có thư mục `~/labtainer-network-base`, script cài đặt (`scripts/install-lab.sh`) sẽ tự động kiểm tra tính tương thích của phiên bản mạng nền và các image cơ sở (`labtainers/labtainer.network.ssh2`).

---

## 3. Hướng dẫn Cài đặt từ File TAR Phát hành

Người dùng trên máy Labtainers mới chỉ cần tải duy nhất file **`rogue-dhcp-snort-v1.0.0.tar`**, giải nén và chạy script cài đặt:

```bash
tar -xf rogue-dhcp-snort-v1.0.0.tar
cd rogue-dhcp-snort
./scripts/install-lab.sh
```
Chi tiết đầy đủ xem tại [INSTALL.md](INSTALL.md) và [PUBLISH_GUIDE.md](PUBLISH_GUIDE.md).

---

## 4. Cách Khởi chạy, Thực hành và Dừng Bài Lab

### Khởi chạy bài lab:
```bash
cd /home/student/labtainer/trunk/scripts/labtainer-student
labtainer -r rogue-dhcp-server
```
*(Tham số `-r` dùng để reset bài lab về trạng thái ban đầu sạch sẽ).*

### Tóm tắt 4 kịch bản thực hành (chi tiết tại [TESTING_GUIDE.md](TESTING_GUIDE.md)):
1. **Kịch bản 1 - Baseline**: Khởi động Snort trên `snort`. Trên `client` chạy `dhclient -v eth0`, nhận Gateway hợp lệ `10.10.0.1`. Snort không cảnh báo.
2. **Kịch bản 2 & 3 - Rogue DHCP & Snort NIDS**: Chạy `python3 /usr/local/bin/rogue_dhcp.py` trên `attacker`. Trên `client` xin cấp lại IP (`dhclient -r eth0 && ip addr flush dev eth0 && dhclient -v eth0`), nhận Default Gateway giả mạo `10.10.0.20`. Snort lập tức cảnh báo `Unauthorized DHCP OFFER` (SID `1000010`) và `Unauthorized DHCP ACK` (SID `1000011`).
3. **Kịch bản 4 - Phòng chống (Mitigation)**: Thêm `echo 'reject 10.10.0.20;' >> /etc/dhcp/dhclient.conf` trên `client`, xin cấp lại IP. Client từ chối gói tin từ `10.10.0.20` và nhận lại Gateway hợp lệ `10.10.0.1`.

### Dừng bài lab & Chấm điểm:
```bash
stoplab rogue-dhcp-server
checkwork rogue-dhcp-server
```

---

## 5. Xử lý lỗi cơ bản (Troubleshooting)
- **Báo `Already exists! Not creating internal_net/external_net subnet`**: Thông báo bình thường khi mạng Docker từ phiên trước còn lưu lại; có thể xóa sạch bằng `stoplab rogue-dhcp-server && docker network rm internal_net external_net`.
- **Client vẫn nhận Gateway `10.10.0.1` khi đang chạy Rogue DHCP**: Do cạnh tranh thời gian phản hồi (Race Condition). Hãy đảm bảo `rogue_dhcp.py` đang chạy trên `attacker` và chạy lại `dhclient -r eth0 && ip addr flush dev eth0 && dhclient -v eth0` trên `client`.
- **Chi tiết đầy đủ**: Xem tại [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
