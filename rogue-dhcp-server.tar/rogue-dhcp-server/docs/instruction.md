# Hướng Dẫn Thực Hành: Rogue DHCP Server & Snort NIDS (Lệnh Trực Tiếp)

---

## BẢNG TỔNG HỢP CÁC TERMINAL

| Terminal | IP | Vai trò chính | Lệnh chủ đạo |
| :--- | :--- | :--- | :--- |
| **`snort`** | `10.10.0.30` | NIDS Sensor | `snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast`<br>`tail -f /var/log/snort/alert` |
| **`attacker`** | `10.10.0.20` | Rogue DHCP Server | `python3 /usr/local/bin/rogue_dhcp.py` |
| **`client`** | `10.10.0.50` -> DHCP | Victim Client | `dhclient -v eth0`<br>`echo 'reject 10.10.0.20;' >> /etc/dhcp/dhclient.conf` |
| **`dhcpserver`** | `192.168.0.100` | DHCP Server thật | `cat /var/lib/dhcp/dhcpd.leases` |

---

## KỊCH BẢN 1: Cấp phát DHCP bình thường (Baseline)

### Bước 1.1: Khởi động Snort trên terminal `snort`
Chạy Snort chế độ daemon ghi log ra file và dùng `tail -f` để xem cảnh báo thời gian thực:
```bash
ip link set eth0 promisc on
snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast
tail -f /var/log/snort/alert
```
*(Màn hình sẽ giữ nguyên và hiển thị cảnh báo ngay khi có sự cố).*

---

### Bước 1.2: Xin cấp IP trên terminal `client`
```bash
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```
* Kiểm tra `ip route show default`: Gateway là `10.10.0.1`.
* Màn hình `snort` không có cảnh báo nào.

---

## KỊCH BẢN 2 & 3: Tấn công Rogue DHCP & Snort phát hiện

### Bước 2.1: Bật Rogue DHCP Server trên terminal `attacker`
```bash
python3 /usr/local/bin/rogue_dhcp.py
```
*(Giữ nguyên cửa sổ này để Rogue DHCP trực chiến).*

---

### Bước 2.2: Yêu cầu cấp lại IP trên terminal `client`
```bash
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```

---

### Bước 2.3: Kiểm tra trên `client` và `snort`
* Trên **`client`**: gõ `ip route show default` -> Gateway chuyển thành `10.10.0.20` (Đầu độc thành công).
* Trên **`snort`**: Cửa sổ `tail -f` lập tức in ra cảnh báo:
  ```text
  [**] [1:1000010:1] [ATTACK] Rogue DHCP Server - Unauthorized DHCP OFFER Detected [**]
  [**] [1:1000011:1] [ATTACK] Rogue DHCP Server - Unauthorized DHCP ACK Detected [**]
  ```

---

## KỊCH BẢN 4: Triển khai Biện pháp Phòng chống (Mitigation)

### Bước 3.1: Thêm quy tắc reject trên `client`
Vẫn giữ Rogue DHCP Server đang chạy trên `attacker`.
Trên terminal **`client`**, gõ lệnh:
```bash
echo 'reject 10.10.0.20;' >> /etc/dhcp/dhclient.conf
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```
* Client từ chối gói tin từ `10.10.0.20` và nhận lại Gateway `10.10.0.1`.

---

### Bước 3.2: Tắt Rogue DHCP Server
Trên terminal **`attacker`**, nhấn `Ctrl + C` hoặc gõ:
```bash
pkill -f rogue_dhcp.py
```

---

## KẾT THÚC VÀ CHẤM ĐIỂM
Quay ra terminal máy host:
```bash
stoplab
checkwork rogue-dhcp-server
```
Toàn bộ các tiêu chí sẽ đạt `Y` (100%).
