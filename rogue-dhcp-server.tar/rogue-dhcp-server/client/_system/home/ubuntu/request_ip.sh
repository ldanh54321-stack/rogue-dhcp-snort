#!/bin/bash
# Request dynamic IP from DHCP Server
echo "=========================================================="
echo "  Requesting Dynamic IP Configuration via DHCP (eth0)   "
echo "=========================================================="
echo "[1] Flushing old IP and releasing current lease..."
sudo dhclient -r eth0 2>/dev/null || true
sudo ip -4 addr flush dev eth0 2>/dev/null || true
sudo ip link set eth0 up

echo "[2] Sending DHCP Discover on eth0..."
sudo dhclient -v eth0

echo ""
echo "[3] Resulting Configuration:"
/home/ubuntu/check_ip.sh
