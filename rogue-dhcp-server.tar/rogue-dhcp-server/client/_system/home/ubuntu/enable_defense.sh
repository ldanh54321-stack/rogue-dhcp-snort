#!/bin/bash
# enable_defense.sh: Host-level DHCP Snooping / Filtering defense
echo "=========================================================="
echo "  Enabling DHCP Snooping / Defense (Host-level Filter)    "
echo "=========================================================="
echo "Policy: Only accept DHCP Offer/ACK (UDP 67->68) from trusted Relay 10.10.0.1"
echo "Dropping all unauthorized DHCP responses from Rogue DHCP (10.10.0.20)."

sudo iptables -F INPUT 2>/dev/null || true
sudo iptables -A INPUT -p udp --sport 67 --dport 68 ! -s 10.10.0.1 -j DROP
sudo iptables -A INPUT -p udp --sport 67 --dport 68 -s 10.10.0.1 -j ACCEPT

mkdir -p /home/ubuntu/.local/result
echo "[$(date)] DEFENSE_ENABLED: Blocked untrusted DHCP responses via iptables" | tee -a /home/ubuntu/.local/result/mitigation.log

echo ""
echo "[OK] Active iptables filter on client:"
sudo iptables -L INPUT -v -n --line-numbers
echo "=========================================================="
