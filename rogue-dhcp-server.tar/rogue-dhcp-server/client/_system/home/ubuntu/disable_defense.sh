#!/bin/bash
# disable_defense.sh: Flush defense filtering
echo "[*] Disabling DHCP Snooping / Filter..."
sudo iptables -F INPUT 2>/dev/null || true
echo "[OK] iptables INPUT rules flushed. Client is now unprotected again."
