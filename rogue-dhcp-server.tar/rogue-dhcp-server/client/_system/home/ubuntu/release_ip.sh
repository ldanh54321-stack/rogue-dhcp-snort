#!/bin/bash
# Release IP address
echo "[*] Releasing DHCP lease on eth0..."
sudo dhclient -r eth0 2>/dev/null || true
sudo ip -4 addr flush dev eth0 2>/dev/null || true
sudo ip link set eth0 up
echo "[OK] Interface eth0 has been reset and IP flushed."
