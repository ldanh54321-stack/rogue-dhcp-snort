#!/bin/bash
echo "=========================================================="
echo "  Client Network Configuration & Lease Status"
echo "=========================================================="
echo "[1] IP Address on eth0:"
ip -4 addr show eth0 | grep inet || echo "  (No IPv4 address assigned!)"

echo ""
echo "[2] Default Gateway (Routing Table):"
ip route show | grep default || echo "  (No default gateway!)"

echo ""
echo "[3] DNS Resolvers (/etc/resolv.conf):"
grep "nameserver" /etc/resolv.conf 2>/dev/null || echo "  (No nameservers found)"

echo ""
echo "[4] Security Analysis:"
GW=$(ip route show default 2>/dev/null | awk '{print $3}')
if [ "$GW" = "10.10.0.1" ]; then
    echo "  >> [LEGITIMATE] Client is using legitimate gateway 10.10.0.1 (via Relay)."
elif [ "$GW" = "10.10.0.20" ]; then
    echo "  >> [COMPROMISED!] Client traffic is POISONED by Rogue DHCP (Gateway 10.10.0.20)."
else
    echo "  >> Gateway: $GW"
fi

echo ""
echo "[5] Latest Lease Details (/var/lib/dhcp/dhclient.leases):"
if [ -f /var/lib/dhcp/dhclient.leases ]; then
    tail -n 18 /var/lib/dhcp/dhclient.leases
fi
echo "=========================================================="
