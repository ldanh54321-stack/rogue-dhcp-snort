#!/bin/bash
echo "================================================================"
echo "  Snort NIDS Status & Rule Verification"
echo "================================================================"
echo "[1] Process Status:"
if pgrep -x snort >/dev/null; then
    ps aux | grep snort | grep -v grep
    echo "  [OK] Snort daemon is RUNNING."
else
    echo "  [INFO] Snort daemon is not running currently."
fi

echo ""
echo "[2] Promiscuous Mode Check:"
ip -d link show eth0 | grep -i promisc && echo "  [OK] eth0 is in PROMISCUOUS mode." || echo "  [WARN] eth0 promisc flag not set."

echo ""
echo "[3] Snort Configuration & Rule Syntax Test:"
sudo snort -T -c /etc/snort/snort.conf -i eth0 > /tmp/snort_test.log 2>&1
if [ $? -eq 0 ]; then
    echo "  [OK] Snort configuration and local.rules are VALID."
else
    echo "  [FAIL] Snort validation error! Check /tmp/snort_test.log:"
    tail -n 15 /tmp/snort_test.log
fi

echo ""
echo "[4] Active Rules in /etc/snort/rules/local.rules:"
grep -v "^#" /etc/snort/rules/local.rules | grep -v "^$"
echo "================================================================"
