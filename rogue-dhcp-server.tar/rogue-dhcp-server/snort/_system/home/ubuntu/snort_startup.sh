#!/bin/bash
# snort_startup.sh
set -e

# Wait for interface
for i in {1..10}; do
    if ip link show eth0 >/dev/null 2>&1; then
        break
    fi
    sleep 1
done

echo "[snort] Setting eth0 to promiscuous mode..."
ip link set eth0 promisc on || true

mkdir -p /etc/snort/rules /var/log/snort /home/ubuntu/rules /home/ubuntu/.local/result
chown -R ubuntu:ubuntu /var/log/snort /home/ubuntu/rules /home/ubuntu/.local 2>/dev/null || true

touch /var/log/snort/alert
chmod 666 /var/log/snort/alert

# Copy rules if needed
if [ -f /home/ubuntu/rules/rogue_dhcp.rules ]; then
    cp /home/ubuntu/rules/rogue_dhcp.rules /etc/snort/rules/local.rules 2>/dev/null || true
fi

# Kill any existing snort process
pkill -9 snort 2>/dev/null || true

# Start Snort daemon in background
echo "[snort] Launching Snort NIDS daemon..."
snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast

echo "[snort] Snort daemon started (PID $(pgrep -x snort)). Ready to monitor."
