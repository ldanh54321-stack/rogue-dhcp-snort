#!/bin/bash
# =============================================================================
# view_alerts.sh – View live Snort NIDS alerts for Rogue DHCP detection
# =============================================================================
ALERT_FILE="/var/log/snort/alert"
CONF_FILE="/etc/snort/snort.conf"

echo "================================================================"
echo "  Snort NIDS Rogue DHCP Alert Monitor"
echo "================================================================"

# Check if Snort is running
if ! pgrep -x snort >/dev/null 2>&1; then
    echo "[*] Snort daemon not running. Starting Snort on eth0..."
    sudo ip link set eth0 promisc on 2>/dev/null || true
    sudo touch "$ALERT_FILE" && sudo chmod 666 "$ALERT_FILE"
    sudo snort -D -q -i eth0 -c "$CONF_FILE" -l /var/log/snort -A fast
    sleep 1
    if pgrep -x snort >/dev/null 2>&1; then
        echo "[OK] Snort daemon started (PID $(pgrep -x snort))."
    else
        echo "[FAIL] Could not start Snort. Testing configuration:"
        sudo snort -T -c "$CONF_FILE"
        exit 1
    fi
else
    echo "[OK] Snort daemon is active (PID $(pgrep -x snort))."
fi

echo ""
echo "Current alert count in $ALERT_FILE: $(wc -l < "$ALERT_FILE" 2>/dev/null || echo 0)"
echo "----------------------------------------------------------------"
echo "Watching for live alerts... (Press Ctrl+C to stop watching)"
echo "----------------------------------------------------------------"
tail -n 20 -F "$ALERT_FILE"
