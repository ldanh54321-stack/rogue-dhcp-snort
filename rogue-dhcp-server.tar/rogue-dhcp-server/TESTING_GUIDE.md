# Hướng Dẫn Kiểm Thử Bằng Lệnh Trực Tiếp (Testing Guide)

Tài liệu này hướng dẫn chi tiết các bước thực hiện trên từng terminal để đạt 100% điểm (`Y`) khi chạy `checkwork`.

---

## BẢNG TỔNG HỢP CÁC TERMINAL

| Cửa sổ Terminal | IP | Vai trò chính | Lệnh chủ đạo |
| :--- | :--- | :--- | :--- |
| **`snort`** | `10.10.0.30` | NIDS Sensor | `snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast`<br>`tail -f /var/log/snort/alert` |
| **`attacker`** | `10.10.0.20` | Rogue DHCP Server | `python3 /usr/local/bin/rogue_dhcp.py` |
| **`client`** | `10.10.0.50` -> DHCP | Victim Client | `dhclient -v eth0`<br>`echo 'reject 10.10.0.20;' >> /etc/dhcp/dhclient.conf` |
| **`dhcpserver`** | `192.168.0.100` | DHCP Server thật | `cat /var/lib/dhcp/dhcpd.leases` |

---

## 1. Kịch bản 1: Cấp phát DHCP bình thường (Baseline)

### Bước 1: Khởi động Snort NIDS trên terminal `snort`
Chạy Snort chế độ ghi log ra file `/var/log/snort/alert` và theo dõi trực tiếp:
```bash
ip link set eth0 promisc on
snort -D -q -i eth0 -c /etc/snort/snort.conf -l /var/log/snort -A fast
tail -f /var/log/snort/alert
```
*(Giữ nguyên màn hình này để xem cảnh báo thời gian thực).*

### Bước 2: Xin cấp IP trên terminal `client`
```bash
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```
* **Kết quả**: Client nhận IP từ DHCP Server thật (`10.10.0.100 - 130`, Gateway `10.10.0.1`). Màn hình Snort hoàn toàn yên lặng.

---

## 2. Kịch bản 2 & 3: Tấn công Rogue DHCP & Snort phát hiện

### Bước 1: Bật Rogue DHCP Server trên terminal `attacker`
```bash
python3 /usr/local/bin/rogue_dhcp.py
```
*(Giữ nguyên cửa sổ này để Rogue DHCP trực chiến).*

### Bước 2: Yêu cầu cấp lại IP trên terminal `client`
```bash
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```

### Bước 3: Đối chiếu kết quả
* **Trên `client`**:
  Kiểm tra default gateway bằng lệnh:
  ```bash
  ip route show default
  ```
  Kết quả hiển thị:
  ```text
  default via 10.10.0.20 dev eth0
  ```
  *(Client đã bị đầu độc thành công, nhận Gateway của Attacker `10.10.0.20`).*

* **Trên `snort`**: Cửa sổ `tail -f` lập tức bắn ra các cảnh báo:
  ```text
  [**] [1:1000010:1] [ATTACK] Rogue DHCP Server - Unauthorized DHCP OFFER Detected [**]
  [**] [1:1000011:1] [ATTACK] Rogue DHCP Server - Unauthorized DHCP ACK Detected [**]
  ```

---

## 3. Kịch bản 4: Triển khai Biện pháp Phòng chống (Mitigation)

### Bước 1: Cấu hình Client từ chối Rogue DHCP Server trên `client`
Vẫn giữ Rogue DHCP Server đang chạy trên `attacker`.
Trên terminal **`client`**, cấu hình chỉ thị `reject`:
```bash
echo 'reject 10.10.0.20;' >> /etc/dhcp/dhclient.conf
dhclient -r eth0
ip addr flush dev eth0
dhclient -v eth0
```
* **Kết quả**:
  - `dhclient` hiển thị dòng từ chối: `DHCPOFFER from 10.10.0.20 rejected by rule 10.10.0.20 mask 255.255.255.255`.
  - Client chỉ nhận cấu hình từ server thật: `bound to 10.10.0.100`.
  - Lệnh `ip route show default` trả về: `default via 10.10.0.1 dev eth0`.

### Bước 2: Dừng Rogue DHCP Server
Trên terminal **`attacker`**, nhấn `Ctrl + C` hoặc gõ:
```bash
pkill -f rogue_dhcp.py
```

---

## 4. Dừng Lab và Chấm Điểm Tự Động
Quay về terminal máy host:
```bash
stoplab
checkwork rogue-dhcp-server
```
Tất cả các tiêu chí sẽ đạt **`Y`** (100%):
```text
Y - client_has_ip
Y - rogue_server_active
Y - snort_detected_offer
Y - snort_detected_ack
Y - client_poisoned
Y - defense_applied
```
