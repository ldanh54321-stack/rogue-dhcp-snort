# Đề Cương Báo Cáo Thực Hành (Report Guide)

Dưới đây là cấu trúc gợi ý chuẩn cho sinh viên khi viết báo cáo bài tập lớn về Rogue DHCP Server và Snort NIDS:

---

## 1. TỔNG QUAN VỀ GIAO THỨC DHCP VÀ TẤN CÔNG ROGUE DHCP
- Quá trình bắt tay 4 bước của DHCP (DORA: Discover -> Offer -> Request -> ACK).
- Vì sao DHCP ban đầu không có cơ chế xác thực nguồn phát.
- Phân tích rủi ro khi có Rogue DHCP Server:
  - Cấp Default Gateway giả mạo -> Kẻ tấn công chặn bắt toàn bộ lưu lượng ra Internet (Man-in-the-Middle).
  - Cấp DNS Server giả mạo -> Điều hướng người dùng đến các trang lừa đảo (DNS Spoofing / Phishing).
  - Cấp subnet không hợp lệ -> Gây tê liệt mạng diện rộng (Denial of Service).

---

## 2. THIẾT KẾ MÔ HÌNH VÀ CẤU HÌNH THỰC NGHIỆM
- Sơ đồ topo mạng 2 subnet (INTERNAL_NET: `192.168.0.0/24`, EXTERNAL_NET: `10.10.0.0/24`).
- Vai trò của Router / DHCP Relay trong việc chuyển tiếp gói tin giữa các subnet.
- Bảng thông số kỹ thuật các máy: IP, MAC, Image sử dụng trong Labtainers.

---

## 3. MÔ PHỎNG TẤN CÔNG BẰNG SCAPY
- Phân tích mã nguồn `rogue_dhcp.py`:
  - Kỹ thuật lọc và bắt gói tin DHCP qua Scapy `sniff()`.
  - Cách thức đóng gói bản tin `DHCP Offer` và `DHCP ACK` với các tùy chọn giả mạo (Option 3 - Router, Option 6 - DNS).
- Chụp ảnh màn hình bằng chứng:
  - Client nhận IP `10.10.0.210` và Default Gateway `10.10.0.20`.
  - Log ghi nhận trên máy tấn công `/var/log/rogue_dhcp.log`.

---

## 4. PHÁT HIỆN BẰNG HỆ THỐNG SNORT NIDS
- Phân tích cú pháp các luật trong `/etc/snort/rules/local.rules`:
  - Giải thích ý nghĩa từng trường: `content:"|02|"`, `offset:236`, `content:"|35 01 02|"`.
  - Phân tích vì sao điều kiện `udp !10.10.0.1 67 -> any 68` phân biệt chính xác gói tin từ Relay và gói tin từ Rogue DHCP Server mà không gây báo động giả (False Positive).
- Chụp ảnh màn hình các dòng cảnh báo trong `/var/log/snort/alert`.

---

## 5. GIẢI PHÁP PHÒNG CHỐNG (MITIGATION)
- Trình bày giải pháp chuẩn trong doanh nghiệp: **DHCP Snooping** trên Switch Layer 2 (Trusted Port vs Untrusted Port).
- Trình bày thực nghiệm phòng chống trên Linux/Host bằng bộ lọc tường lửa `iptables`.
- Đối chiếu bảng cấu hình của Client trước và sau khi kích hoạt phòng chống.

---

## 6. KẾT LUẬN VÀ BÀI HỌC KINH NGHIỆM
- Đánh giá hiệu quả của hệ thống phát hiện xâm nhập Snort.
- Những điểm cần lưu ý khi thiết kế bảo mật cho mạng phân tầng có DHCP Relay.
