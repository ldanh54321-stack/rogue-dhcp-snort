#!/bin/bash
if [ -f /usr/local/share/Student.py.safe ]; then
    cp -f /usr/local/share/Student.py.safe /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
    chmod 775 /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
    chown ubuntu:ubuntu /home/ubuntu/.local/bin/Student.py 2>/dev/null || true
fi

exec 9>/var/lock/rogue-dhcp-role-init.lock
flock -n 9 || exit 0
if [ -f /var/run/rogue_dhcp_role_initialized ]; then
    exit 0
fi

ROLE="$(hostname)"
if [ -d "/opt/lab-roles/${ROLE}" ]; then
    cp -rf "/opt/lab-roles/${ROLE}/." /
    chmod +x /home/ubuntu/*.sh /home/ubuntu/*.py /usr/local/bin/*.py /usr/local/bin/*.sh /home/ubuntu/.local/bin/* 2>/dev/null || true
    chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
fi

case "${ROLE}" in
    dhcpserver)
        mkdir -p /var/lib/dhcp
        touch /var/lib/dhcp/dhcpd.leases
        chown dhcpd:dhcpd /var/lib/dhcp/dhcpd.leases 2>/dev/null || true
        ip route add 10.10.0.0/24 via 192.168.0.1 dev eth0 2>/dev/null || true
        pkill -x dhcpd 2>/dev/null || true
        /usr/sbin/dhcpd -4 -cf /etc/dhcp/dhcpd.conf -pf /var/run/dhcpd.pid eth0 2>/dev/null || true
        ;;
    dhcprelay)
        sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1 || true
        tc qdisc del dev eth0 root 2>/dev/null || true
        tc qdisc add dev eth0 root netem delay 100ms 2>/dev/null || true
        pkill -x dhcrelay 2>/dev/null || true
        /usr/sbin/dhcrelay -4 -i eth0 -i eth1 192.168.0.100 2>/dev/null || true
        ;;
    snort)
        mkdir -p /var/log/snort /etc/snort/rules
        touch /var/log/snort/alert
        chmod 666 /var/log/snort/alert
        chown -R ubuntu:ubuntu /var/log/snort 2>/dev/null || true
        ;;
    attacker)
        ;;
    client)
        ip -4 addr flush dev eth0 2>/dev/null || true
        ip link set eth0 up 2>/dev/null || true
        ;;
esac

touch /var/run/rogue_dhcp_role_initialized
exit 0
